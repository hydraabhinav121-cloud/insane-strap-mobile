# Insane Strap Mobile v2

Red-and-black Flutter Android prototype inspired by the provided profile screenshot.

## Included
- Mobile-only Flutter app UI
- Red/black home dashboard and editable admin profile
- Discord connection entry point (opens Discord Developer Portal; OAuth is not implemented)
- Profile labels (session-only)
- JSON editor with validation/formatting
- Pro tab with demo key `INSANE-DEMO-PRO`
- Prototype screens for key generation and granting Pro by username

## Important: prototype vs production
The current Pro key and profile data are local demo state only. Admin actions do not create real keys or grant server-backed Pro. Discord is not linked until OAuth is implemented. Do not distribute this as a production license system yet.

For production:
1. Create a Discord application in the Discord Developer Portal.
2. Implement OAuth2 authorization-code flow using a backend; keep client secrets only on the server.
3. Add Firebase Authentication/Firestore and secure Cloud Functions (or another backend).
4. Store admin allowlist and entitlements server-side; validate every grant/redeem request in backend code.
5. Persist profiles and JSON presets locally with a preferences/database package.
6. Add file import/export via Android document picker.
7. Test Android SDK compatibility and review app permissions.

## Build on Windows
Install Flutter stable and Android Studio/Android SDK, then run `flutter doctor`.
Extract ZIP, open PowerShell in the project folder:
```powershell
flutter create --platforms=android .
flutter pub get
flutter run
flutter build apk --release
```
APK output:
`buildpp\outputslutter-apkpp-release.apk`

Use a real Android device with USB debugging or an emulator. This project targets Android only; it does not provide a Windows app.

## Build APK using only your phone (GitHub Actions)

1. On your phone, sign in to GitHub and create a new repository named `insane-strap-mobile`.
2. Upload the project files from this ZIP to the repository root, including the hidden `.github/workflows/build-apk.yml` file. If mobile upload hides dot-folders, create `.github/workflows/build-apk.yml` using GitHub's web editor and paste the workflow from this file.
3. Open the repository's **Actions** tab and select **Build Insane Strap Android APK**.
4. Tap **Run workflow** (or wait for the first push-triggered build).
5. Open the completed workflow run and download the artifact named `insane-strap-android-apk`.
6. Extract the downloaded artifact ZIP to find `app-release.apk`, then install it on your Android phone.

If the repository is private, GitHub Actions usage is subject to your account's included minutes and limits. This workflow compiles the current prototype; it does not add production Discord OAuth or server-backed premium licensing.
