import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const InsaneStrapApp());

const red = Color(0xFFFF3048);
const bg = Color(0xFF070607);
const panel = Color(0xFF121012);
const muted = Color(0xFFAAA4AE);

class InsaneStrapApp extends StatelessWidget {
  const InsaneStrapApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Insane Strap',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: red, brightness: Brightness.dark),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Colors.white12)),
      ),
    ),
    home: const Shell(),
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int index = 0;
  bool isPro = false;
  bool discordConnected = false;
  String username = 'Insane Admin';
  String handle = '@insane_admin';
  String bio = 'I run things, not follow them.\nBigger goals. Darker dreams.\nINSANE.';
  final profiles = <String>['Main Account'];
  final keyController = TextEditingController();
  final jsonController = TextEditingController(text: const JsonEncoder.withIndent('  ').convert({
    'examplePreset': {'note': 'Sample preset only', 'flags': <String, dynamic>{}}
  }));

  @override
  void dispose() {
    keyController.dispose();
    jsonController.dispose();
    super.dispose();
  }

  void toast(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  @override
  Widget build(BuildContext context) {
    final pages = [home(), profile(), profilesPage(), flagsPage(), proPage()];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.local_fire_department, color: red, size: 28),
          SizedBox(width: 8),
          Text('INSANE STRAP', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.5)),
        ]),
        actions: [Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Center(child: pill(isPro ? 'PRO' : 'FREE', isPro)),
        )],
      ),
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF100C0E),
        indicatorColor: red.withOpacity(.18),
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Accounts'),
          NavigationDestination(icon: Icon(Icons.data_object), label: 'FFlags'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'Pro'),
        ],
      ),
    );
  }

  Widget pill(String text, bool active) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: active ? red.withOpacity(.14) : Colors.white10,
      border: Border.all(color: active ? red : Colors.white24),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(text, style: TextStyle(color: active ? red : Colors.white, fontWeight: FontWeight.w900)),
  );

  Widget card(Widget child, {EdgeInsets padding = const EdgeInsets.all(16)}) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: panel,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: Colors.white.withOpacity(.09)),
      boxShadow: [BoxShadow(color: red.withOpacity(.035), blurRadius: 18)],
    ),
    child: child,
  );

  Widget heading(String s) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(s.toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4, fontSize: 13, color: muted)),
  );

  Widget actionButton(String label, IconData icon, VoidCallback onTap, {bool filled = false}) => SizedBox(
    height: 48,
    child: filled
      ? FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: red, foregroundColor: Colors.white), onPressed: onTap, icon: Icon(icon), label: Text(label))
      : OutlinedButton.icon(style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: red)), onPressed: onTap, icon: Icon(icon, color: red), label: Text(label)),
  );

  Widget home() => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: red.withOpacity(.65)),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF30080D), Color(0xFF100C0E), Color(0xFF070607)]),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.local_fire_department, color: red, size: 34),
        SizedBox(height: 12),
        Text('YOUR GAME. YOUR SETUP.', style: TextStyle(color: red, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        SizedBox(height: 8),
        Text('Insane Strap', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
        SizedBox(height: 6),
        Text('A mobile companion for profiles, presets, and account tools.', style: TextStyle(color: muted)),
      ]),
    ),
    const SizedBox(height: 18),
    Row(children: [
      Expanded(child: card(const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.people, color: red), SizedBox(height: 8), Text('PROFILES'), Text('Local labels', style: TextStyle(color: muted))]))),
      const SizedBox(width: 12),
      Expanded(child: card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.workspace_premium, color: red), const SizedBox(height: 8), Text(isPro ? 'PRO ACTIVE' : 'FREE PLAN'), const Text('Access tier', style: TextStyle(color: muted))]))),
    ]),
    const SizedBox(height: 20),
    heading('Quick tools'),
    quickTile(Icons.person, 'Admin profile', 'Profile, Discord connection, and premium tools', () => setState(() => index = 1)),
    quickTile(Icons.key, 'Premium access', 'Redeem a key or review Pro status', () => setState(() => index = 4)),
    quickTile(Icons.data_object, 'FFlags JSON editor', 'Edit and validate JSON locally', () => setState(() => index = 3)),
    const SizedBox(height: 12),
    const Text('Android note: other apps’ windows, RAM, FPS, graphics, and Roblox runtime flags are restricted. This app does not bypass those restrictions.', style: TextStyle(color: muted, fontSize: 12)),
  ]);

  Widget quickTile(IconData icon, String title, String subtitle, VoidCallback tap) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: card(ListTile(contentPadding: EdgeInsets.zero, leading: Icon(icon, color: red), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: tap)),
  );

  Widget profile() => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.fromLTRB(18, 22, 18, 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: red.withOpacity(.5)),
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF21070B), bg]),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 76, height: 76, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF20090D), border: Border.all(color: red, width: 2), boxShadow: [BoxShadow(color: red.withOpacity(.2), blurRadius: 16)]), child: const Icon(Icons.local_florist, color: red, size: 38)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('!! $username', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(handle, style: const TextStyle(color: muted)),
            const SizedBox(height: 8),
            Wrap(spacing: 7, children: [pill('♛ ADMIN', true), if (isPro) pill('PRO', true)]),
          ])),
        ]),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: actionButton('Edit Profile', Icons.edit, editProfile)),
        const SizedBox(height: 18),
        const Row(children: [Expanded(child: Center(child: Text('PROFILE', style: TextStyle(fontWeight: FontWeight.bold)))), Expanded(child: Center(child: Text('WISHLIST', style: TextStyle(color: muted))))]),
        const Divider(color: Colors.white12, height: 24),
        card(Row(children: [const Icon(Icons.verified_user, color: red, size: 30), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('ACCOUNT STATUS', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.2)), Text(isPro ? 'ADMIN • PRO' : 'ADMIN • FREE', style: const TextStyle(color: red, fontWeight: FontWeight.w900, fontSize: 19)), const Text('Admin controls are backend-verified in production.', style: TextStyle(color: muted, fontSize: 12))]))])),
      ]),
    ),
    const SizedBox(height: 14),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.discord, size: 32), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Discord Connection', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), Text('Link your Discord account', style: TextStyle(color: muted))]))]),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: Text(discordConnected ? '● Connected (demo state)' : '● Not connected', style: TextStyle(color: discordConnected ? Colors.greenAccent : red, fontWeight: FontWeight.bold))),
        OutlinedButton.icon(
          onPressed: connectDiscord,
          icon: const Icon(Icons.link, color: red),
          label: Text(discordConnected ? 'Reconnect' : 'Connect Discord'),
          style: OutlinedButton.styleFrom(side: const BorderSide(color: red), foregroundColor: Colors.white),
        ),
      ]),
      const SizedBox(height: 6),
      const Text('Real Discord OAuth needs a Discord application, a redirect URL, and a backend. This button opens Discord setup instructions; it does not falsely claim the account is linked.', style: TextStyle(color: muted, fontSize: 11)),
    ])),
    const SizedBox(height: 14),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.workspace_premium, color: red, size: 30), SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Premium Management', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Text('Generate keys or grant Pro to users.', style: TextStyle(color: muted))]))]),
      const SizedBox(height: 14),
      actionButton('Generate Pro Key', Icons.key, () => setState(() => index = 4), filled: true),
      const SizedBox(height: 10),
      actionButton('Grant Pro to User', Icons.person_add_alt_1, () => setState(() => index = 4)),
      const SizedBox(height: 8),
      const Text('These buttons open a prototype screen. Real key generation and user grants require the secure backend.', style: TextStyle(color: muted, fontSize: 11)),
    ])),
    const SizedBox(height: 14),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('BIO', style: TextStyle(fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text(bio, style: const TextStyle(color: muted, height: 1.5)),
      Align(alignment: Alignment.centerRight, child: IconButton(onPressed: editProfile, icon: const Icon(Icons.edit, color: red))),
    ])),
  ]);

  Future<void> editProfile() async {
    final nameC = TextEditingController(text: username);
    final handleC = TextEditingController(text: handle);
    final bioC = TextEditingController(text: bio);
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Edit profile'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: nameC, decoration: const InputDecoration(labelText: 'Display name')),
        const SizedBox(height: 10),
        TextField(controller: handleC, decoration: const InputDecoration(labelText: 'Handle')),
        const SizedBox(height: 10),
        TextField(controller: bioC, maxLines: 3, decoration: const InputDecoration(labelText: 'Bio')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save'))],
    ));
    if (ok == true) setState(() { username = nameC.text.trim().isEmpty ? username : nameC.text.trim(); handle = handleC.text.trim(); bio = bioC.text; });
    nameC.dispose(); handleC.dispose(); bioC.dispose();
  }

  Future<void> connectDiscord() async {
    final uri = Uri.parse('https://discord.com/developers/applications');
    try { await launchUrl(uri, mode: LaunchMode.externalApplication); }
    catch (_) { toast('Open Discord Developer Portal in your browser.'); }
    toast('Discord OAuth is not configured yet. Create an application and configure the backend before enabling sign-in.');
  }

  Widget profilesPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('ACCOUNT PROFILES', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
    const SizedBox(height: 6),
    const Text('Profile labels only. Do not store Roblox passwords, cookies, or tokens.', style: TextStyle(color: muted)),
    const SizedBox(height: 14),
    ...profiles.asMap().entries.map((e) => Padding(padding: const EdgeInsets.only(bottom: 8), child: card(ListTile(leading: const Icon(Icons.person, color: red), title: Text(e.value), subtitle: const Text('Saved for this session'), trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: profiles.length <= 1 ? null : () => setState(() => profiles.removeAt(e.key)))))),
    actionButton('Add profile', Icons.add, addProfile, filled: true),
  ]);

  Future<void> addProfile() async {
    final c = TextEditingController();
    final result = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(title: const Text('Add profile'), content: TextField(controller: c, decoration: const InputDecoration(labelText: 'Profile label')), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Add'))]));
    c.dispose();
    if (result != null && result.isNotEmpty) setState(() => profiles.add(result));
  }

  Widget flagsPage() => Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('FFLAGS JSON WORKSPACE', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    const Text('Edit and validate JSON locally. This does not inject flags into Roblox.', style: TextStyle(color: muted)),
    const SizedBox(height: 12),
    Expanded(child: TextField(controller: jsonController, expands: true, maxLines: null, minLines: null, style: const TextStyle(fontFamily: 'monospace', fontSize: 13), decoration: const InputDecoration(hintText: '{ }'))),
    const SizedBox(height: 10),
    Row(children: [
      Expanded(child: actionButton('Validate', Icons.check_circle_outline, validateJson)),
      const SizedBox(width: 8),
      Expanded(child: actionButton('Format', Icons.auto_fix_high, formatJson, filled: true)),
    ]),
  ]));

  void validateJson() { try { jsonDecode(jsonController.text); toast('Valid JSON ✓'); } catch (_) { toast('Invalid JSON. Check brackets, quotes, and commas.'); } }
  void formatJson() { try { jsonController.text = const JsonEncoder.withIndent('  ').convert(jsonDecode(jsonController.text)); toast('JSON formatted ✓'); } catch (_) { toast('Cannot format invalid JSON.'); } }

  Widget proPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('PRO & ADMIN', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
    const SizedBox(height: 12),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.workspace_premium, color: red, size: 36),
      const SizedBox(height: 8),
      Text(isPro ? 'PRO ACTIVE (LOCAL DEMO)' : 'FREE PLAN', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const Text('Local demo controls only. Production entitlements must be checked by a backend.', style: TextStyle(color: muted)),
      const SizedBox(height: 14),
      TextField(controller: keyController, decoration: const InputDecoration(labelText: 'Redeem demo key', hintText: 'INSANE-DEMO-PRO')),
      const SizedBox(height: 10),
      actionButton('Redeem key', Icons.key, () {
        if (keyController.text.trim().toUpperCase() == 'INSANE-DEMO-PRO') { setState(() => isPro = true); toast('Local demo Pro enabled.'); }
        else { toast('Key not recognized. Real key verification is not connected yet.'); }
      }, filled: true),
    ])),
    const SizedBox(height: 14),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ADMIN ACTIONS', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
      const SizedBox(height: 8),
      const Text('Prototype only — no keys or user grants are written to a server yet.', style: TextStyle(color: muted)),
      const SizedBox(height: 12),
      actionButton('Generate Pro Key', Icons.vpn_key, () => showAdminDialog(true)),
      const SizedBox(height: 10),
      actionButton('Grant Pro to Username', Icons.person_add_alt_1, () => showAdminDialog(false), filled: true),
      const SizedBox(height: 10),
      actionButton('Reset local demo to Free', Icons.restart_alt, () => setState(() => isPro = false)),
    ])),
  ]);

  Future<void> showAdminDialog(bool keyMode) async {
    final c = TextEditingController();
    final d = TextEditingController(text: '30');
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: Text(keyMode ? 'Generate Pro key (prototype)' : 'Grant Pro to user (prototype)'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: c, decoration: InputDecoration(labelText: keyMode ? 'Optional key note' : 'Registered username')),
        const SizedBox(height: 10),
        TextField(controller: d, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Duration in days')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () {
        Navigator.pop(ctx);
        toast(keyMode ? 'Prototype only: connect secure backend to generate real keys.' : 'Prototype only: connect secure backend to grant Pro to a registered user.');
      }, child: const Text('Continue'))],
    ));
    c.dispose(); d.dispose();
  }
}
